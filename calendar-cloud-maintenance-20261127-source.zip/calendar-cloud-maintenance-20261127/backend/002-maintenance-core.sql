-- Requires phase 1 (version/status/deleted_at + version trigger).
-- Invoker-only private functions: never callable by app users through the Data API.
create schema if not exists calendar_private;
revoke all on schema calendar_private from public,anon,authenticated;

create table if not exists calendar_private.maintenance_runs (
  run_id bigint generated always as identity primary key,
  business_date date not null,
  started_at timestamptz not null,
  finished_at timestamptz not null default clock_timestamp(),
  moved_todos integer not null,
  archived_schedules integer not null
);
revoke all on calendar_private.maintenance_runs from public,anon,authenticated;
alter table calendar_private.maintenance_runs enable row level security;

create or replace function calendar_private.item_date(p_payload jsonb)
returns date language plpgsql immutable strict set search_path = '' as $$
declare value text := p_payload->>'date'; parsed date;
begin
  if value is null or value !~ '^\d{4}-\d{2}-\d{2}$' then return null; end if;
  parsed := value::date;
  if to_char(parsed,'YYYY-MM-DD') <> value then return null; end if;
  return parsed;
exception when datetime_field_overflow or invalid_datetime_format then return null;
end $$;
revoke all on function calendar_private.item_date(jsonb) from public,anon,authenticated;

create or replace function calendar_private.maintain_daily(
  p_today date default (current_timestamp at time zone 'Asia/Shanghai')::date
) returns jsonb language plpgsql set search_path = '' as $$
declare started timestamptz := clock_timestamp(); moved integer; archived integer;
begin
  if p_today is null then raise exception 'Business date cannot be null'; end if;
  if not pg_try_advisory_xact_lock(73928610412026::bigint) then
    return jsonb_build_object('skipped',true,'reason','already_running');
  end if;
  -- UPDATE rechecks row conditions after concurrent row-lock waits.
  -- The existing calendar_version trigger bumps version and updated_at.
  update public.calendar_items
    set payload=jsonb_set(payload,'{date}',to_jsonb(to_char(p_today,'YYYY-MM-DD')),false)
    where status='active' and deleted_at is null
      and payload->>'type'='待办' and coalesce(payload->>'done','false')<>'true'
      and calendar_private.item_date(payload)<p_today;
  get diagnostics moved = row_count;
  update public.calendar_items set status='archived'
    where status='active' and deleted_at is null
      and payload->>'type'='日程' and calendar_private.item_date(payload)<p_today;
  get diagnostics archived = row_count;
  insert into calendar_private.maintenance_runs(business_date,started_at,moved_todos,archived_schedules)
    values(p_today,started,moved,archived);
  return jsonb_build_object('business_date',p_today,'moved_todos',moved,'archived_schedules',archived);
end $$;
revoke all on function calendar_private.maintain_daily(date) from public,anon,authenticated;

create index if not exists calendar_items_maintenance_active
  on public.calendar_items ((payload->>'type'),(payload->>'date'))
  where status='active' and deleted_at is null;
