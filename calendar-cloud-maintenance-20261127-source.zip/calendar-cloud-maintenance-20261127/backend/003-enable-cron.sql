-- Run only after core and transaction-rollback tests pass.
begin;
create table if not exists calendar_private.calendar_items_before_cloud_maintenance
  as table public.calendar_items;
revoke all on calendar_private.calendar_items_before_cloud_maintenance from public,anon,authenticated;
alter table calendar_private.calendar_items_before_cloud_maintenance enable row level security;

create extension if not exists pg_cron with schema pg_catalog;
grant usage on schema cron to postgres;
grant all privileges on all tables in schema cron to postgres;
do $$ begin
  if coalesce(current_setting('cron.timezone',true),'GMT') not in ('GMT','UTC','Etc/UTC') then
    raise exception 'Cron timezone must be checked before enabling the UTC schedule';
  end if;
end $$;
-- UTC 16:05 = next day 00:05 in Asia/Shanghai. Named schedule is an upsert.
select cron.schedule('calendar-daily-maintenance','5 16 * * *',
  $job$set lock_timeout='5s'; set statement_timeout='30s'; select calendar_private.maintain_daily();$job$);
commit;

-- An initial catch-up is safe and idempotent; no physical DELETE is used.
select calendar_private.maintain_daily();
select jobid,jobname,schedule,active,username from cron.job
  where jobname='calendar-daily-maintenance';
