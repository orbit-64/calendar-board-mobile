-- Administrator-only verification. App users have no access to the private schema.
select jobid,jobname,schedule,active,username from cron.job
where jobname='calendar-daily-maintenance';
select r.status,r.return_message,r.start_time,r.end_time
from cron.job_run_details r join cron.job j using(jobid)
where j.jobname='calendar-daily-maintenance' order by r.runid desc limit 10;
select business_date,moved_todos,archived_schedules,started_at,finished_at
from calendar_private.maintenance_runs order by run_id desc limit 10;
