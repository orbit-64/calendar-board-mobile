const assert = require('node:assert/strict');
const fs = require('node:fs'), vm=require('node:vm'), path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8');
const values=new Map();const context=vm.createContext({Date,JSON,String,atob,console,
 localStorage:{getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)}});
vm.runInContext(source.slice(0,source.indexOf("$('setupForm').addEventListener")),context);
(async()=>{
 vm.runInContext('render=()=>{};showStatus=()=>{};state.session={user_id:"A"};writes=[];writeItem=async(...args)=>writes.push(args);fetchItems=async()=>[{id:"a",type:"待办",date:"2020-01-01",_status:"active"},{id:"b",type:"日程",date:"2020-01-01",_status:"active"}];',context);
 await vm.runInContext('loadItems()',context);
 assert.equal(vm.runInContext('writes.length',context),0,'Loading must never maintain remote data');
 assert.equal(vm.runInContext('state.items[0].date',context),'2020-01-01');
 assert.equal(vm.runInContext('state.items[1]._status',context),'active');
 vm.runInContext('state.session={user_id:"B"};fetchItems=async()=>{throw Error("offline")};',context);
 values.set('calendar-board-cache-v2-A','[{"title":"private"}]');
 await vm.runInContext('loadItems()',context);assert.equal(vm.runInContext('state.items.length',context),0);
 let resolve;context.pending=new Promise(r=>resolve=r);vm.runInContext('fetchItems=()=>pending;',context);
 const pending=vm.runInContext('loadItems()',context);vm.runInContext('clearLocalAccount()',context);resolve([{title:'old'}]);await pending;
 assert.equal(vm.runInContext('state.items.length',context),0);
 console.log('PASS: read-only load, unchanged dates/status, account isolation and logout race');
})().catch(e=>{console.error(e);process.exitCode=1});
