-- Run against production only inside this rollback transaction: no fixtures persist.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
set local time zone 'America/Los_Angeles';
do $$
declare actor uuid; today date := (now() at time zone 'Asia/Shanghai')::date;
  response jsonb; item public.calendar_items%rowtype; original_count bigint;
begin
  select id into actor from auth.users limit 1;
  if actor is null then raise exception 'A user is required for test fixture ownership'; end if;
  select count(*) into original_count from public.calendar_items;
  insert into public.calendar_items(id,user_id,payload,status,deleted_at)
  select md5('calendar-maintenance-test-'||n),actor,
    jsonb_build_object('id',md5('calendar-maintenance-test-'||n),'title','maintenance test',
      'type',case when n in (1,2,7,9) then '待办' when n=6 then '课程' else '日程' end,
      'date',case when n=4 then today::text when n=5 then (today+2)::text
                 when n=10 then '2026-99-99' else (today-2)::text end)
      || case when n in (1,7) then '{"done":false}'::jsonb
              when n=9 then '{"done":true}'::jsonb else '{}'::jsonb end,
    case when n=7 then 'completed' else 'active' end,
    case when n=8 then now() else null end
  from generate_series(1,10) as n;

  response := calendar_private.maintain_daily();
  if response->>'business_date' <> today::text then raise exception 'Wrong business timezone'; end if;
  for n in 1..10 loop
    select * into strict item from public.calendar_items where id=md5('calendar-maintenance-test-'||n);
    if n in (1,2) then
      if item.payload->>'date'<>today::text or item.version<>2 then raise exception 'Todo rollover failed: %',n; end if;
    elsif n=3 then
      if item.status<>'archived' or item.version<>2 or item.deleted_at is not null
        or item.payload->>'date'<>(today-2)::text then raise exception 'Archive must preserve payload/history'; end if;
    else
      if item.version<>1 then raise exception 'Protected row changed: %',n; end if;
    end if;
  end loop;
  response := calendar_private.maintain_daily();
  if (response->>'moved_todos')::int<>0 or (response->>'archived_schedules')::int<>0 then
    raise exception 'Repeated run is not idempotent';
  end if;
  if (select count(*) from public.calendar_items)<>original_count+10 then raise exception 'Rows were physically removed'; end if;
  if has_function_privilege('anon','calendar_private.maintain_daily(date)','EXECUTE')
    or has_function_privilege('authenticated','calendar_private.maintain_daily(date)','EXECUTE')
    or has_schema_privilege('authenticated','calendar_private','USAGE') then raise exception 'Maintenance is exposed to app users'; end if;
  if (timestamptz '2026-11-27 15:59:59+00' at time zone 'Asia/Shanghai')::date<>date '2026-11-27'
    or (timestamptz '2026-11-27 16:00:00+00' at time zone 'Asia/Shanghai')::date<>date '2026-11-28'
    then raise exception 'Midnight boundary incorrect'; end if;
  perform set_config('request.jwt.claim.sub',actor::text,true);
  begin
    perform public.calendar_save(md5('calendar-maintenance-test-1'),1,
      jsonb_build_object('type','待办','title','stale edit','date',today::text),'active',false);
    raise exception 'Stale version was accepted';
  exception when serialization_failure then null;
  end;
end $$;
select 'PASS: timezone, 10 fixtures, idempotency, history, private access, stale-write conflict' as result;
rollback;
