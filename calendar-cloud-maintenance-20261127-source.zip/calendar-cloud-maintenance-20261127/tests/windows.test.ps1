﻿$ErrorActionPreference='Stop'
$fixture=Join-Path $PSScriptRoot ('run-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $fixture | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot '../windows/Render.ps1'),(Join-Path $PSScriptRoot '../windows/Maintain.ps1') -Destination $fixture
$entries=@(
 @{id=('a'*32);type='待办';title='pending';date='2020-01-01';done=$false},
 @{id=('b'*32);type='日程';title='past';date='2020-01-01'},
 @{id=('c'*32);type='日程';title='archived';date='2020-01-01';_status='archived'}
)
$file=Join-Path $fixture 'events.json'
[IO.File]::WriteAllText($file,(ConvertTo-Json -InputObject $entries),[Text.UTF8Encoding]::new($true))
$before=(Get-FileHash -LiteralPath $file).Hash
$compat=& (Join-Path $fixture 'Maintain.ps1')
& (Join-Path $fixture 'Render.ps1') -Action Today | Out-Null
if((Get-FileHash -LiteralPath $file).Hash-ne $before){throw 'Rendering or old shortcut modified events'}
if(-not $compat.CloudManaged){throw 'Legacy maintenance shim did not report cloud ownership'}
if(-not(Test-Path -LiteralPath (Join-Path $fixture 'CalendarData.inc'))){throw 'Rendering failed'}
'PASS: Render produces calendar without local rollover, archive or data mutation'
