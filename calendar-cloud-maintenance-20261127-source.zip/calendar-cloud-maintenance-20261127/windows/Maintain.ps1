﻿param([datetime]$Now = (Get-Date))
# Compatibility shim for older shortcuts. Cloud Cron owns daily data maintenance.
# Do not modify dates/status locally or run rollover against stale cache.
[pscustomobject]@{Moved=0;Deleted=0;CloudManaged=$true}
